## 2.Matritsani transpose qilish: ichma-ich sikl, comprehension va zip(*m) bilan.
m = [
    [1, 2, 3],
    [4, 5, 6]
]

## 1
res = []
for i in range(len(m[0])):    
    qator = []
    for j in range(len(m)):  
        qator.append(m[j][i])  
    res.append(qator)

## 2
res = [[ m[j][i] for j in range(len(m))] for i in range(len(m[0]))]
print(res)


## 3
res = [list(q) for q in zip(*m)]

print(res)


