##  1.forsiz aylanish: iter()/next() bilan list, satr, dict va faylni, StopIterationni o'zi tutadi.

with open('ch/data.txt', 'r', encoding= 'utf-8') as l:

    lindex = iter(l)

    while True:
        try:
            print(next(lindex)) 
        except:
            StopIteration
            break





