for i in range(3):
    pass     # pass hech nima qilmaydi loopni ham toxtatmaydi 
    print(i)

