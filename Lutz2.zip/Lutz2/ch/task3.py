
import sys 

a = [i for i in range(1, 1000000+1)]

b = (x for x in range(1, 10000000+1))

print(sys.getsizeof(a)) # koproq joy egallaydi 
print(sys.getsizeof(b)) # xotiradan kamroq joy oladi 
