x = 10  # Global

def tashqi():
    x = 20  # Enclosing

    def ichki():
        x = 30  # Local
        return x

    def ozgartir():
        nonlocal x
        x = 40

    ozgartir()
    return ichki(), x

natija, tashqi_x = tashqi()

assert natija == 30
assert tashqi_x == 40
assert x == 10