# a = [lambda x: x * i for i in range(3)]

# print(a[0](5)) 
# print(a[1](5))
# print(a[2](5))

# hammasining natijasi bir xil 10 chiqadi chunki i kech boglanadi va oxirgi loop da qotadi

a = [lambda x, i = i: x * i for i in range(3)]

print(a[0](5)) 
print(a[1](5))
print(a[2](5))

# endi har safar yangi natija boladi chunki endi i = i qilib biz har bir i ni oldik