## ake_counter() closure — har chaqirilganda keyingi sonni qaytaradi.
def make_counter():
    count = 0
    def plus():
        nonlocal count
        count += 1
        return count
    return plus

c = make_counter()
print(c())
print(c())
