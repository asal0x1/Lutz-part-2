# UnboundLocalError: local variable 'x' referenced before assignment
x = 10
def f():
    print(x)
    x = 5
f()

# UnboundLocalError: local variable 'x' referenced before assignment
# bu yerda error chunki funksiyada global ozgaruvchini ishlatmoqchi