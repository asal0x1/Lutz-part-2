# 2.  1–100 oralig'idagi tub sonlar — flag o'zgaruvchisiz, for/else bilan.

for n in range(2, 101):
    for i in range(2, n):
        if n % i == 0: 
            break
    else:
        print(n)       


