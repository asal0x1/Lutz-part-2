# 1.FizzBuzz 2 xil: if/elif va dict orqali.

## 1.
n = input("Number: ")
n = int(n)
for i in range(1, n+1):
    if i % 3== 0 and i % 5 == 0:
        print("FizzBuzz")
    elif i % 3 == 0:
        print("Fizz")
    elif i % 5 == 0:
        print("Buzz")
    else:
        print(i)

## 2.
n = input("Number: ")
n = int(n)
D = {
    3: 'Fizz',
    5: 'Buzz',
}
for i in range(1, n+1):
    res = ""
    for d, word in D.items():
        if i % d == 0:
            res += word

    print(res or i)