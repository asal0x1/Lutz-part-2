# 3."Sonni top" o'yini: 1–100, maksimal 7 urinish, "katta/kichik" deydi, noto'g'ri kiritilsa qayta so'raydi.

import random
r = random.randint(1, 100)

life = 7
while life > 0:
    guess = input("Guess the number: ")
    guess = int(guess)
    if guess > r:
        life -= 1
        print(f'Kichik {life} urunishingiz qoldi')
       
    elif guess < r:
        life -= 1
        print(f'Katta {life} urunishingiz qoldi')
        
    else:
        print('Toptingiz 🥳')
        break






