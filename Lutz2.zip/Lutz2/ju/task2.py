def f(x=[]):
    x.append(1)
    print(x)

f()
f()
f()

## bu funksiyada bitta listga funksiya har safar ishlaganida unga qiymat qoshib ketaveradi 
# buni oldini olish uchun funksiya ishga tushunrilganda x boshqatan yaratiladi 

def f(x = None):
    if x is None:
        x = []
    x.append(1)
    print(x)

f()
f()
f()