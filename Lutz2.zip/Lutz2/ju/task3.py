

talabalar = {
    "Ali": 85,
    "Vali": 95,
    "Aziza": 95,
    "Sardor": 75
}

natija = sorted(
    talabalar.items(),
    key=lambda talaba: (-talaba[1], talaba[0])
)

print(natija)




