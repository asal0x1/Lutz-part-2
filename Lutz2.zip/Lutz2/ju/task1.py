def api_call(url, /, *args, timeout=5, **headers):
    print(url)
    print(args)
    print(timeout)
    print(headers)
    
# togri chaqiruv
api_call("https://chatgpt.com", 10, 20, timeout=10, Authorization ='token', Accept = 'json')


#api_call(url = "https://chatgpt.com", 10, 'token', 'json' )

# bunisida hammasi notogri chaqirilgan 