# 1.Unpacking: a, b = b, a; first, *rest = [1, 2, 3, 4]; ichma-ich (a, b), c = (1, 2), 3.
a,b = b,a
# bu yerda ozgaruvchilar bir birini qiymatini oladi va ikkalasini ham qiymati ozgaradi

first, *rest = [1, 2, 3, 4]

# bitta obyektga ikkita ozgaruvchi boglanadi first birinchisini oladi
# *rest esa qolgan hammasini list qilib oladi 
# va ikkita * bolishi mumkun emas 

(a, b), c = (1, 2), 3

## unpacking qilish uchun togri reference kerak 
## bu yerda (a, b) = (1, 2) ga teng va shunday korinishda yoziladi
## c esa 3 ni oladi
 




