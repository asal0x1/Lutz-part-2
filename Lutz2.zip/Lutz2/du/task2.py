
l = [1, 2, 3]
b = l
l+= [4]
print(l)
print(b)
print(id(l))
print(id(b))

## b va l bitta obyektga boglandi va ularnning id lari bir xil
# l += [4] shu obyektga 4 ni qoshadi va bu ikkita ozgaruvchiga ham tasir qiladi

l = [1, 2, 3]
b = l
l = l + [4]
print(l)
print(b)
print(id(l))
print(id(b))

## bu yerda ham b va l bitta obyektga boglandi 
#lekin l = l + [4] bu yerda l obyektiga 4 ni qoshib yangi obyekt yaratiladi 
# va unga l ozgaruvchi beriladi shuning uchun b ozgarmadi va ularning id lari xar xil

