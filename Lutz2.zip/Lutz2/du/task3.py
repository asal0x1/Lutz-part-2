# 3.printni faylga yozdirish (file=), sep va end bilan jadval chiqarish.

with open('file.txt', 'w', encoding='utf-8') as f:
    print("Ism", "Yosh", "Shahar", file=f, sep = ' | ')
    print("-" * 30, file = f)
    print('Ali', '20', 'Toshkent', file = f, sep= ' | ')
    print('Vali', '22', 'Smarqand', file= f, sep = ' | ')
    print('Soli', '19', 'Buxoro', file = f, sep = ' | ', end = '\n')